#1/usr/bin/bash

rm -f config.h
sudo make clean install

